# Cahier des charges : site internet de Ébénisterie Exemple

Référence CDC-ebenisterie-exemple-20261110-AB12 · client fictif de recette, aucune donnée réelle.

## 1. Entreprise
Atelier d’ébénisterie à Lyon (Croix-Rousse), deux ébénistes. Meubles sur mesure, cuisines et restauration de meubles anciens. Zone : Lyon et 30 km autour.

## 2. Projet
Premier site. Objectif : recevoir des demandes de devis qualifiées pour des meubles et cuisines sur mesure.

## 3. Cibles
- Propriétaires d’appartements anciens qui rénovent (moment : achat ou rénovation ; frein : peur du prix).
- Architectes d’intérieur qui cherchent un atelier fiable (moment : nouveau chantier ; frein : délais).

Réponses du site à leurs hésitations : montrer des réalisations avec leurs étapes ; expliquer comment se construit un devis ; dire les délais habituels quand le client les donnera.

## 4. Offre
- Service phare : cuisine sur mesure en bois massif.
- Meubles sur mesure (bibliothèques, dressings, tables).
- Restauration de meubles anciens.
Accroche du client, en ses mots : « Des meubles qui gardent la mémoire du bois. »
Ce qui distingue : tout est fait à l’atelier, à la main, avec des bois choisis chez des scieries de la région.
Preuves : label Entreprise du patrimoine vivant (certificat fourni). Aucun avis client fourni.

## 5. Contenu page par page
- Accueil : accroche, trois services, une réalisation, comment se passe un projet, demande de devis. À rédiger par Claude, 250 à 400 mots.
- L’atelier : histoire (fournie en entretien), les deux ébénistes, les bois. À rédiger par Claude, 300 à 500 mots.
- Réalisations : galerie avec légendes (photos à fournir).
- Cuisines sur mesure, Meubles sur mesure, Restauration : une page par service, 300 à 500 mots chacune.
- Demande de devis : formulaire.
- Mentions légales, confidentialité.

## 6. Identité visuelle
Logo fourni (SVG). Pas de charte « à respecter » : jetons proposés. Le client aime le bois en grand, peu de texte, des photos d’atelier ; il n’aime pas les carrousels ni les sites sombres.

## 7. Contact et rendez-vous
Formulaire de demande de devis (projet, pièce, dimensions approximatives, budget indicatif, délai souhaité). Téléphone de l’atelier affiché. Visite de l’atelier sur rendez-vous.

## 8. Contenus et médias
Photos de l’atelier fournies en partie ; photos de réalisations à fournir.

**Plan de collecte**

- Photos des réalisations récentes
- Liste des essences de bois travaillées

## 9. Référencement
Mots-clés : ébéniste Lyon, cuisine sur mesure Lyon, meuble sur mesure Lyon, restauration meuble ancien Lyon. Données structurées : LocalBusiness (HomeAndConstructionBusiness).

## 10. Glossaire et ton éditorial
Ton : simple, précis, chaleureux, « nous ». Vocabulaire : essences, assemblages, tenons et mortaises, finitions à l’huile.
Mots à éviter : « pas cher », « numéro 1 ».

## 11. Juridique et conformité
Mentions légales et politique de confidentialité ; mention du label EPV avec son année d’obtention (à fournir).

## 12. Technique
Domaine : ebenisterie-exemple.fr (à acheter). Site en français. Pas de boutique.

## 13. Planning et priorités
Must : accueil, l’atelier, services, devis. Should : réalisations. Could : actualités.

## 14. Recette
Le formulaire de devis arrive par e-mail ; le site est lisible sur téléphone ; les pages se chargent vite.
