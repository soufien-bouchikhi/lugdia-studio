# Découverte · Ébénisterie Exemple

Entretien du 12 novembre 2026, enregistré et transcrit.

## Histoire

Atelier ouvert en 2010.

## Clients types

- Particuliers

## Moments déclencheurs

- Déménagement

## Hésitations des clients

(vide)

## Mots du client

- fait main

## Concurrents cités

(vide)

## Preuves

(aucune)
