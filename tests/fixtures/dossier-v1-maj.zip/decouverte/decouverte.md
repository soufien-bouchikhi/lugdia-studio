# Découverte · Ébénisterie Exemple

Entretien du 12 novembre 2026, enregistré et transcrit.

## Histoire

Atelier ouvert en 1998 à Lyon par un compagnon du devoir ; trois ébénistes depuis 2026.

## Clients types

- Propriétaires d’appartements anciens
- Architectes d’intérieur

## Moments déclencheurs

- Rénovation d’un appartement haussmannien

## Hésitations des clients

- Peur d’un prix trop élevé

## Mots du client

- du sur-mesure qui dure
- le bois a sa mémoire

## Concurrents cités

- Menuiserie du Rhône

## Preuves

- Label Entreprise du patrimoine vivant (label) · source : certificat vu le 12/11/2026 · confirmée
- 400 cuisines posées (chiffre) · source : Entretien du 12/11/2026, dit par le client (à confirmer)
- Prix régional de l’artisanat (label) · sans source (à confirmer)
